package com.example.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;


public class mAdapter extends ArrayAdapter<Course> {
    private Context mContext;
    int mResource;
    ArrayList<Course> x;
    public mAdapter(Context context, int resource, ArrayList<Course> objects){
        super(context,resource,objects);
        mContext=context;
        mResource=resource;
        this.x=objects;

    }
    @Override
    public View getView(int position,View convertview,ViewGroup parent){
        LayoutInflater inflater=LayoutInflater.from(mContext);
        convertview=inflater.inflate(mResource,parent,false);
        int ID=getItem(position).getID();
        String CourseCode=getItem(position).getCourseCode();
        String CourseName=getItem(position).getCourseName();
        TextView tvID=(TextView) convertview.findViewById(R.id.t0);
        TextView tvCourseCode=(TextView) convertview.findViewById(R.id.t1);
        TextView tvCourseName=(TextView) convertview.findViewById(R.id.t2);
        tvID.setText(""+ID);
        tvCourseCode.setText(CourseCode);
        tvCourseName.setText(CourseName);
        return convertview;
    }
}
