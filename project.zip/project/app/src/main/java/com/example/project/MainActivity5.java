package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity5 extends AppCompatActivity {
    TextView tv5;
    TextView tv6;
    TextView tv7;
    TextView tv8;

    EditText coursecode1;
    EditText coursename1;
    EditText courseday1;

    ListView productlist1;
    ArrayList<Course> enrolledcourse;
    mAdapter adapter;
    MyDBHandler m;
    String x;
    String y;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        tv5 = (TextView) findViewById(R.id.tv5);
        tv6 = (TextView) findViewById(R.id.tv6);
        tv7 = (TextView) findViewById(R.id.tv7);
        tv8 = (TextView) findViewById(R.id.tv8);

        y = MDBHandler.getP();
        x = MainActivity.getX();
        tv5.setText("Welcome" + x + "!You are logged in as ‘student ’.");
        tv7.setText("name:" + y);
        tv8.setText("username:" + x);

        coursecode1 = (EditText) findViewById(R.id.tv16);
        coursename1 = (EditText) findViewById(R.id.tv17);
        courseday1 = (EditText) findViewById(R.id.tv18);
        productlist1 = (ListView) findViewById(R.id.lv1);
        enrolledcourse = new ArrayList<>();
        MainActivity2 n = MainActivity2.getn();
        m = new MyDBHandler(n);
    }

    public void findCourse1(View view) {
        int m0 = 0;
        ArrayList<Course> locallistItem = new ArrayList<>();
        Course q = new Course();
        String op = "" + coursecode1.getText().toString();
        String po = "" + coursename1.getText().toString();
        String oo = "" + courseday1.getText().toString();
        if (op != "" && po != "") {

            ArrayList<Course> d = MainActivity2.getcourseafterfindCourse2(coursename1.getText().toString(), coursecode1.getText().toString());
            if (d != null) {
                m0 = 1;
                adapter = new mAdapter(this, R.layout.myadapter_layout, d);
                productlist1.setAdapter(adapter);
            } else {
                Toast.makeText(this, "input course name or course error", Toast.LENGTH_SHORT).show();
            }
        } else if (po != "") {
            ArrayList<Course> e = MainActivity2.getcourseafterfindCourse3(coursename1.getText().toString());
            if (e != null) {
                m0 = 1;
                adapter = new mAdapter(this, R.layout.myadapter_layout, e);
                productlist1.setAdapter(adapter);
            }
        } else if (op != "") {
            ArrayList<Course> f = MainActivity2.getcourseafterfindCourse4(coursecode1.getText().toString());
            if (f != null) {
                m0 = 1;
                adapter = new mAdapter(this, R.layout.myadapter_layout, f);
                productlist1.setAdapter(adapter);
            }
        } else if (oo != "") {
            ArrayList<Course> g = m.findCourse5(oo);
            if (g != null) {
                m0 = 1;
                adapter = new mAdapter(this, R.layout.myadapter_layout, g);
                productlist1.setAdapter(adapter);
            }
        }
        if (m0 != 1) {

            Toast.makeText(this, "input error", Toast.LENGTH_SHORT).show();
        }

    }

    public void enrollCourse(View view) {
        String op = "" + coursecode1.getText().toString();
        String po = "" + coursename1.getText().toString();
        String f="";
        if (op != "" && po != "") {
            ArrayList<Course> target = m.findCourse2(coursename1.getText().toString(), coursecode1.getText().toString());
            if(enrolledcourse.isEmpty()){
                Cursor e = m.findCourse(coursename1.getText().toString(), coursecode1.getText().toString());
                if(e.getString(8)!=null){
                    f = e.getString(8)+" "+ y;
                }else{
                    f = " "+ y;
                }
                ArrayList<Course> h=MainActivity2.getcourseaftereditCourse(coursename1.getText().toString(), coursecode1.getText().toString(), f);
                Course g=new Course(Integer.valueOf(e.getString(0)),e.getString(1),e.getString(2)
                        ,e.getString(3),e.getString(4),e.getString(5),e.getString(6),
                        e.getString(7),f);
                enrolledcourse.add(g);
                adapter = new mAdapter(this, R.layout.myadapter_layout, h);
                productlist1.setAdapter(adapter);
            }else{
                for (Course l : enrolledcourse) {
                    if (l.equals(target.get(0))) {
                        Toast.makeText(this, "you have enrolled this course", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, target.get(0).getcoursehours(), Toast.LENGTH_SHORT).show();
                        if(l.timeconfict(target.get(0))){
                            Toast.makeText(this, "you have time conflict", Toast.LENGTH_SHORT).show();
                        }else {
                            Cursor w = m.findCourse(coursename1.getText().toString(), coursecode1.getText().toString());
                            String a = w.getString(8);
                            a = a +" "+ y;
                            ArrayList<Course> h=MainActivity2.getcourseaftereditCourse(coursename1.getText().toString(), coursecode1.getText().toString(), a);
                            Course b=new Course(Integer.valueOf(w.getString(0)),w.getString(1),w.getString(2)
                                    ,w.getString(3),w.getString(4),w.getString(5),w.getString(6),
                                    w.getString(7),a);
                            enrolledcourse.add(b);
                            Toast.makeText(this, "enroll Course successfully", Toast.LENGTH_SHORT).show();
                            adapter = new mAdapter(this, R.layout.myadapter_layout, h);
                            productlist1.setAdapter(adapter);
                        }
                    }

                }
            }

        }

    }
    public void viewEnrolledCourse(View view) {
        adapter = new mAdapter(this, R.layout.myadapter_layout, enrolledcourse);
        productlist1.setAdapter(adapter);
    }

    public void unenrollCourse(View view) {
        String op = "" + coursecode1.getText().toString();
        String po = "" + coursename1.getText().toString();
        int z=-1;
        if (op != "" && po != "") {
            ArrayList<Course> target = m.findCourse2(coursename1.getText().toString(), coursecode1.getText().toString());

            for (int i = 0; i < enrolledcourse.size(); i++) {
                if (enrolledcourse.get(i).equals(target.get(0))) {
                    z=i;
                    break;
                }

            }
            if(z!=-1){
                enrolledcourse.remove(z);
                Cursor w=m.findCourse(coursename1.getText().toString(), coursecode1.getText().toString());
                String a=w.getString(8);
                String[] b=a.split(" ");
                String result="";
                for (String l:b){
                    if(!(l.equals(y))){
                        result=result+l;
                    }
                }
                ArrayList<Course> h=MainActivity2.getcourseaftereditCourse(coursename1.getText().toString(), coursecode1.getText().toString(),result);
                Toast.makeText(this, "unenroll Course successfully", Toast.LENGTH_SHORT).show();
                adapter = new mAdapter(this, R.layout.myadapter_layout, h);
                productlist1.setAdapter(adapter);
            }
            else {
                Toast.makeText(this, "you do not enrolled this course", Toast.LENGTH_SHORT).show();
            }

        }
    }
}