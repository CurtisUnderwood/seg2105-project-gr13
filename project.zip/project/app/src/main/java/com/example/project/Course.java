package com.example.project;

import java.util.ArrayList;

public class Course {
    private int _id;
    private String _coursecode;
    private String _coursename;
    private String instructorname;
    private String coursedays;
    private String coursehours;
    private String coursedescription;
    private String studentcapacity;
    private String enrolledstudent;

    // constructors
    public Course() {
    }
    public Course(int id,String coursecode, String coursename,String instructorname, String coursedays,String coursehours, String coursedescription,String studentcapacity,String enrolledstudent) {
        _id = id;
        _coursecode = coursecode;
        _coursename = coursename;
        this.instructorname = instructorname;
        this.coursedays = coursedays;
        this.coursehours = coursehours;
        this.coursedescription = coursedescription;
        this.studentcapacity = studentcapacity;
        this.enrolledstudent=enrolledstudent;

    }
    public Course(int id, String coursecode, String coursename) {
        _id = id;
        _coursecode = coursecode;
        _coursename = coursename;
    }
    public Course(int id,String coursecode, String coursename,String instructorname, String coursedays,String coursehours, String coursedescription,String studentcapacity) {
        _id = id;
        _coursecode = coursecode;
        _coursename = coursename;
        this.instructorname = instructorname;
        this.coursedays = coursedays;
        this.coursehours = coursehours;
        this.coursedescription = coursedescription;
        this.studentcapacity = studentcapacity;

    }
    public Course(String coursecode, String coursename) {
        _coursecode = coursecode;
        _coursename = coursename;
    }
    // setters and getters
    public void setID(int id) {
        _id = id;
    }
    public int getID() {
        return _id;
    }
    public void setCourseCode(String coursecode) {
        _coursecode = coursecode;
    }
    public String getCourseCode() {
        return _coursecode;
    }
    public void setcourseName(String coursename) {
        _coursename = coursename;
    }
    public String getCourseName() {
        return _coursename;
    }

    public void setinstructorname(String instructorname) {
        this.instructorname = instructorname;
    }
    public String getinstructorname() {
        return instructorname;
    }

    public void setcoursedays(String coursedays) {
        this.coursedays = coursedays;
    }
    public String getcoursedays() {
        return coursedays;
    }

    public void setcoursehours(String coursehours) {
        this.coursehours = coursehours;
    }
    public String getcoursehours() {
        return coursehours;
    }

    public void setcoursedescription(String coursedescription) {
        this.coursedescription = coursedescription; }
    public String getcoursedescription() {
        return coursedescription;
    }

    public void setstudentcapacity(String studentcapacity) {
        this.studentcapacity = studentcapacity;
    }
    public String getstudentcapacity() {
        return studentcapacity;
    }

    public void setenrolledstudent(String enrolledstudent) {
        this.enrolledstudent = enrolledstudent;
    }
    public String getenrolledstudent() {
        return enrolledstudent;
    }
    public boolean equals(Course x ){
        return _id==x.getID()&&_coursecode.equals(x.getCourseCode())
                &&_coursename.equals(x.getCourseName())&&coursedays.equals(x.getcoursedays())
                &&coursehours.equals(x.getcoursehours()) &&coursedescription.equals(x.getcoursedescription())
                &&studentcapacity.equals(x.getstudentcapacity())&&enrolledstudent.equals(x.getenrolledstudent())
                &&instructorname.equals(x.getinstructorname());

    }
    public boolean timeconfict(Course x ){
        ArrayList<Integer> y=dayEquals( x );
        ArrayList<Integer> z=timeEquals( x );
        for (int i : y) {
            for (int j : z) {
                if(i==j){
                    return true;
                }
            }
        }
        return false;
    }
    public ArrayList<Integer> dayEquals(Course x ){
        ArrayList<Integer> listItem = new ArrayList<>();
        String[] y=getcoursedays().split(" ");
        String[] z=x.getcoursedays().split(" ");
        for(int i=0;i<y.length;i++){
            for(int j=0;j<z.length;j++){
                if(y[i].equals(z[j])){
                    listItem.add(i);
                    break;
                }
            }
        }
        return listItem;

    }
    public ArrayList<Integer> timeEquals(Course x ){
        ArrayList<Integer> listItem = new ArrayList<>();
        String[] y=getcoursehours().split(" ");
        String[] z=x.getcoursehours().split(" ");
        for(int i=0;i<y.length;i++){
            for(int j=0;j<z.length;j++){
                String [] timeperoidy=y[i].split("-");
                String [] timeperoidz=z[i].split("-");
                char[] testystart=timeperoidy[0].toCharArray();
                char[] testzstart=timeperoidz[0].toCharArray();
                if(testystart.length==4){
                    timeperoidy[0]="0"+timeperoidy[0];
                }
                if(testzstart.length==4){
                    timeperoidz[0]="0"+timeperoidz[0];
                }
                if((timeperoidy[0].compareTo(timeperoidz[0])>=0 && timeperoidy[0].compareTo(timeperoidz[1])<0)
                        ||(timeperoidy[1].compareTo(timeperoidz[0])>0 && timeperoidy[1].compareTo(timeperoidz[1])<=0)){
                    listItem.add(i);
                }

            }
        }
        return listItem;


    }
}


