package com.example.project;

public class Course {
        private int _id;
        private String _coursecode;
        private String _coursename;

        // constructors
        public Course() {
        }
        public Course(int id, String coursecode, String coursename) {
            _id = id;
            _coursecode = coursecode;
            _coursename = coursename;
        }
        public Course(String coursecode, String coursename) {
            _coursecode = coursecode;
            _coursename = coursename;
        }

        // setters and getters
        public void setID(int id) {
            _id = id;
        }
        public int getID() {
            return _id;
        }
        public void setCourseCode(String coursecode) {
            _coursecode = coursecode;
        }
        public String getCourseCode() {
            return _coursecode;
        }
        public void setcourseName(String coursename) {
            _coursename = coursename;
        }
        public String getCourseName() {
            return _coursename;
        }
    }


