package com.example.project;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBHandler<privare> extends SQLiteOpenHelper {
    //defining the schema
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "productDB.db";
    private static final String TABLE_PRODUCTS = "course";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_PRODUCTNAME = "coursecode";
    private static final String COLUMN_PRICE = "coursename";


    // constructor
    public MyDBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // create the table
    @Override
    public void onCreate(SQLiteDatabase db) {
        // CREATE TABLE TABLE_PRODUCTS (COLUMN_ID INTEGER PRIMARY KEY, COLUMN_PRODUCTNAME TEXT,
        // COLUMN_PRICE DOUBLE)
        String CREATE_PRODUCTS_TABLE = "CREATE TABLE " + TABLE_PRODUCTS
                + "(" + COLUMN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_PRODUCTNAME + " TEXT,"
                + COLUMN_PRICE + " TEXT" +
                ")";
        db.execSQL(CREATE_PRODUCTS_TABLE);
    }

    // deletes old tables and creates a new one
    // change tables by incrementing the database version number
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUCTS);
        onCreate(db);
    }

    // insert into database
    public void addProduct(Course course) {
        SQLiteDatabase db = this.getWritableDatabase();

        // creating an empty set of values
        ContentValues values = new ContentValues();
        // add values to the set
        values.put(COLUMN_PRODUCTNAME, course.getCourseCode());
        values.put(COLUMN_PRICE, course.getCourseName());

        // insert the set into the products table and close
        db.insert(TABLE_PRODUCTS, null, values);
        db.close();
    }

    // find a product from database
    public void editProduct(String productname, String coursecode) {
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteDatabase q = this.getWritableDatabase();
        // run a query to find the product with the specified product name
        // SELECT * FROM TABLE_PRODUCTS WHERE COLUMN_PRODUCTNAME = "productname"
        String query = "SELECT * FROM " + TABLE_PRODUCTS
                + " WHERE " + COLUMN_PRODUCTNAME
                + " = \"" + productname + "\"";
        // passing the query
        String x = "SELECT * FROM " + TABLE_PRODUCTS
                + " WHERE " + COLUMN_PRICE
                + " = \"" + coursecode + "\"";
        Cursor y = q.rawQuery(x, null);

        Cursor cursor = db.rawQuery(query, null);

        Course product = new Course();

        // moves cursor to the first row
        if (cursor.moveToFirst()) {
            String idStr = cursor.getString(0);
            db.delete(TABLE_PRODUCTS, COLUMN_ID + " = " + idStr, null);

            ContentValues values = new ContentValues();
            values.put(COLUMN_PRODUCTNAME, productname);
            values.put(COLUMN_PRICE, coursecode);
            db.insert(TABLE_PRODUCTS, null, values);

        }else if(y.moveToFirst()){

                String p = y.getString(0);
                q.delete(TABLE_PRODUCTS, COLUMN_ID + " = " + p, null);

                ContentValues z = new ContentValues();
                z.put(COLUMN_PRODUCTNAME, productname);
                z.put(COLUMN_PRICE, coursecode);
                q.insert(TABLE_PRODUCTS, null, z);}



        db.close();
        q.close();
    }

    // delete from database
    public boolean deleteProduct(String productname) {
        boolean result = false;
        SQLiteDatabase db = this.getWritableDatabase();

        // run a query to find the product with the specified name, then delete
        // SELECT * FROM TABLE_PRODUCTS WHERE COLUMN_PRODUCTNAME = productname
        String query = "SELECT * FROM " + TABLE_PRODUCTS
                + " WHERE " + COLUMN_PRODUCTNAME
                + " = \"" + productname + "\"";

        // passing the query
        Cursor cursor = db.rawQuery(query, null);

        // moves cursor to the first row
        // this deletes the first occurrence of the product with the specified name
        if (cursor.moveToFirst()) {
            String idStr = cursor.getString(0);
            db.delete(TABLE_PRODUCTS, COLUMN_ID + " = " + idStr, null);
            cursor.close();
            result = true;
        }
        db.close();

        // if product is deleted this returns true
        return result;
    }

    // read all from table
    public Cursor viewData() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_PRODUCTS;

        // passing the query
        Cursor cursor = db.rawQuery(query, null);

        // returns all products from table
        return cursor;
    }



}