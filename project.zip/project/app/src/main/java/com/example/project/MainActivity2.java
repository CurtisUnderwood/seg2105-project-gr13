package com.example.project;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity2 extends Activity {

    TextView idView;
    EditText productBox;
    EditText priceBox;

    ListView productlist;
    ArrayList<Course> listItem;
    mAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // set variables to the ids of .xml elements
        idView = (TextView) findViewById(R.id.ID);
        productBox = (EditText) findViewById(R.id.coursecode);
        priceBox = (EditText) findViewById(R.id.coursename);
        productlist = (ListView) findViewById(R.id.productListView);

        MyDBHandler dbHandler = new MyDBHandler(this);
        listItem = new ArrayList<>();

        // call the viewData() method to display the existing products
        viewData();

    }

    // we use onClick for the Add button in our layout to call this method
    public void newProduct (View view) {
        MyDBHandler dbHandler = new MyDBHandler(this);

        // get price from the text box
        String price = priceBox.getText().toString();

        // get product name from the text box
        // use the constructor from Product.java
        Course product = new Course(productBox.getText().toString(), price);

        // add to database with the addProduct() method from MyDBHandler.java
        dbHandler.addProduct(product);

        // clear the text boxes
        productBox.setText("");
        priceBox.setText("");

        // clearing the list of products
        // calling viewData() method to display the updated list of products
        // this means what is displayed in the ListView is always current
        listItem.clear();
        viewData();
        Intent intent=new Intent(MainActivity2.this , MainActivity2.class);
        startActivity(intent);
    }

    // we use onClick for the Find button in our layout to call this method
    public void editCourse (View view) {
        MyDBHandler dbHandler = new MyDBHandler(this);

        // get product in the database using findProduct() method from MyDBHandler.java
        dbHandler.editProduct(productBox.getText().toString(),priceBox.getText().toString());

        // if found, then display the product details
        // if not, display "No Match Found"

            idView.setText(String.valueOf(""));
            productBox.setText("");
            priceBox.setText(String.valueOf(""));

        listItem.clear();
        viewData();
        Intent intent=new Intent(MainActivity2.this , MainActivity2.class);
        startActivity(intent);
    }

    // we use onClick for the Delete button in our layout to call this method
    public void removeProduct (View view) {
        MyDBHandler dbHandler = new MyDBHandler(this);

        // delete product in the database using deleteProduct() method from MyDBHandler.java
        boolean result = dbHandler.deleteProduct(productBox.getText().toString());

        // clearing the list of products
        // calling viewData() method to display the updated list of products
        // this means what is displayed in the ListView is always current
        listItem.clear();
        viewData();

        // "Record Deleted" or "No Match Found"
        if (result) {
            idView.setText("Record Deleted");
            productBox.setText("");
            priceBox.setText("");
        }
        else
            idView.setText("No Match Found");
        Intent intent=new Intent(MainActivity2.this , MainActivity2.class);
        startActivity(intent);
    }

    private void viewData(){
        MyDBHandler dbHandler = new MyDBHandler(this);

        // call the viewData() method in MyDBHandler that runs the query
        Cursor cursor = dbHandler.viewData();

        // if there are no products in the table a toast says there is no data to show
        // otherwise, while there are products, keep moving to the next product
        if(cursor.getCount() == 0){
            Toast.makeText(this, "Not data to show", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                // I just want to display the product name so I only get column 1 from the table row
                Course x=new Course(Integer.valueOf(cursor.getString(0)),cursor.getString(1),cursor.getString(2));
                listItem.add(x);
            }
            // create an array adapter that provides a view for each item
            // simple_list_item_1 is a built-in xml layout from Android
            // I decided to use this instead of creating my own .xml file for items of the ListView
            adapter = new mAdapter(this,R.layout.myadapter_layout , listItem);

            // attaching the adapter to the ListView
            productlist.setAdapter(adapter);
        }
    }

}