package com.example.project;

import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ExampleTest2 {
    @Test
    public void CourseConstructor() {
        Course x=new Course(1,"ITI1121", "computer","gray"
                , "monday tuesday","11:00-12:00 14:00-16:00",
                "coding course","40","zhang wang li zhao");
        assertEquals("Clickadd failed", 1, x.getID());
        assertEquals("Clickadd failed", "ITI1121", x.getCourseCode());
        assertEquals("Clickadd failed", "computer", x.getCourseName());
        assertEquals("Clickadd failed", "gray", x.getinstructorname());
        assertEquals("Clickadd failed", "monday tuesday", x.getcoursedays());
        assertEquals("Clickadd failed", "11:00-12:00 14:00-16:00", x.getcoursehours());
        assertEquals("Clickadd failed", "coding course", x.getcoursedescription());
        assertEquals("Clickadd failed", "40", x.getstudentcapacity());
        assertEquals("Clickadd failed", "zhang wang li zhao", x.getenrolledstudent());
    }

    @Test
    public void CourseDayEquals() {
        Course x=new Course(1,"ITI1121", "computer","gray"
                , "monday tuesday","11:00 - 12:00 14:00 - 16:00",
                "coding course","40","zhang wang li zhao");
        Course y=new Course(1,"ITI1121", "computer","gray"
                , "monday tuesday","11:00 - 12:00 14:00 - 16:00",
                "coding course","40","zhang wang li zhao");
        Course z=new Course(1,"ITI1121", "computer","gray"
                , "sunday","11:00-12:00 14:00 - 16:00",
                "coding course","40","zhang wang li zhao");
        ArrayList<Integer> listItem = new ArrayList<>();
        listItem.add(0);
        listItem.add(1);
        assertEquals("Clickadd failed", listItem,x.dayEquals(y));
        ArrayList<Integer> listItem1 = new ArrayList<>();
        assertEquals("Clickadd failed", listItem1,x.dayEquals(z));
    }
    @Test
    public void CoursetimeEquals() {
        Course x=new Course(1,"ITI1121", "computer","gray"
                , "monday tuesday","11:00-12:00 14:00-16:00",
                "coding course","40","zhang wang li zhao");
        Course y=new Course(1,"ITI1121", "computer","gray"
                , "monday tuesday","11:00-12:00 14:00-16:00",
                "coding course","40","zhang wang li zhao");
        ArrayList<Integer> listItem = new ArrayList<>();
        listItem.add(0);
        listItem.add(0);
        listItem.add(1);
        listItem.add(1);
        assertEquals("Clickadd failed", listItem,x.timeEquals(y));
    }
    @Test
    public void Coursetimeconfict() {
        Course x=new Course(1,"ITI1121", "computer","gray"
                , "monday tuesday","11:00-12:00 14:00-16:00",
                "coding course","40","zhang wang li zhao");
        Course y=new Course(1,"ITI1121", "computer","gray"
                , "monday tuesday","11:00-12:00 14:00-16:00",
                "coding course","40","zhang wang li zhao");
        Course z=new Course(1,"ITI1121", "computer","gray"
                , "sunday","11:00-12:00 14:00-16:00",
                "coding course","40","zhang wang li zhao");

        assertTrue("Clickadd failed",x.timeconfict(y));
        assertFalse("Clickadd failed",x.timeconfict(z));
    }
    @Test
    public void Courseequals() {
        Course x=new Course(1,"ITI1121", "computer","gray"
                , "monday tuesday","11:00-12:00 14:00-16:00",
                "coding course","40","zhang wang li zhao");
        Course y=new Course(1,"ITI1121", "computer","gray"
                , "monday tuesday","11:00-12:00 14:00-16:00",
                "coding course","40","zhang wang li zhao");
        assertTrue("Clickadd failed",x.equals(y));
    }
}